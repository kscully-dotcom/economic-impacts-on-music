from billscrapes import billscrapes as bs

bs.create_january_dataset()
bs.create_february_dataset()
bs.create_march_dataset()
bs.create_april_dataset()
bs.create_may_dataset()
bs.create_june_dataset()
bs.create_july_dataset()
bs.create_august_dataset()
bs.create_september_dataset()
bs.create_october_dataset()
bs.create_november_dataset()
bs.create_december_dataset()